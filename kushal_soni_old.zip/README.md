--------------- Kushal Soni Practical ----------------

Admin Details
URL : http://127.0.0.1:8000/admin/login
Username : admin
Password : Admin@123

Admin Details
URL : http://127.0.0.1:8000/login
Username : user1
Password : User@123

API Collection (Json) : https://api.postman.com/collections/12887336-29d5ff52-7093-4cea-85e0-8f54dbedd36f?access_key=PMAT-01H75MDTA2HS90GWN94QN2TYPF

------------------------------------------------------