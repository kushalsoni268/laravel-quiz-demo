<?php

return array(  
    'roleAdmin' => 1,
    'roleUser' => 2,
    'roleAdminText' => 'Admin',
    'roleUserText' => 'User',

    'superAdminPass' => 'Admin@123',
    'userPass' => 'User@123',

    'testPending' => 0,
    'testAttended' => 1,
    'testPendingText' => 'Pending',
    'testAttendedText' => 'Attended',

    'answerIncorrect' => 0,
    'answerCorrect' => 1,
    'answerIncorrectText' => 'Incorrect',
    'answerCorrectText' => 'Correct',
);