<tr>
	<td style="padding: 0 30px 20px; font-family: 'Open Sans','Lucida Grande','Segoe UI',Arial,Verdana,'Lucida Sans Unicode',Tahoma,'Sans Serif'; font-size: 11pt; line-height: 27px; color: #444; text-align: left;">
                <p style="margin: 0;">Thank you very much.</p>
                <p style="margin: 0;">Web Team</p>
                <h6 style="margin: 0;"><center>{{ now()->year }} &copy; Demo | All rights reserved</center></h6>
	</td>
</tr>