
<?php $__env->startSection('content'); ?>
<tr>
	<td style="padding: 20px 30px 30px; font-family: 'Open Sans','Lucida Grande','Segoe UI',Arial,Verdana,'Lucida Sans Unicode',Tahoma,'Sans Serif'; font-size: 11pt; line-height: 27px; color: #444; text-align: left;">
		<p style="margin: 0;">Hello <?php echo e($name); ?>,</p>
	</td>
</tr>
<tr>
	<td style="padding: 0 30px 30px; font-family: 'Open Sans','Lucida Grande','Segoe UI',Arial,Verdana,'Lucida Sans Unicode',Tahoma,'Sans Serif'; font-size: 11pt; line-height: 27px; color: #444; text-align: left;">
		<p style="margin: 0;">Your test has been completed.</p>
	</td>
</tr>
<tr>
	<td style="padding: 0 30px 30px; font-family: 'Open Sans','Lucida Grande','Segoe UI',Arial,Verdana,'Lucida Sans Unicode',Tahoma,'Sans Serif'; font-size: 11pt; line-height: 27px; color: #444; text-align: left;">
		<p style="margin: 0;"><b>Total Score : </b> <?php echo e($total_score); ?>/<?php echo e($total_question); ?></p>
		<p style="margin: 0;"><b>Total Time Taken : </b> <?php echo e($total_time); ?></p>
	</td>
</tr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('mail.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kushal_soni\resources\views/mail/emailresult.blade.php ENDPATH**/ ?>